dod_medic by StrontiumDog
http://www.theville.org

See it in operation at
TheVille.Org II - DoD v1.3 Custom Maps FF on
[game: Day of Defeat] 63.210.145.199:27015 

1. Copy dod_medic.amxx to addons/amxmodx/plugins folder
2. Edit plugins.ini (in addons/amxmodx/configs folder) and add "dod_medic.amxx" to end of file
3. Place sound folder in main dod folder and allow it to copy the medic folder into the sound folder....

Update your fast download server as well, if you have one!
