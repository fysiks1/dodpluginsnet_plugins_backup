This plugin changes the sounds in the default stats.amxx to female ultimate sounds. 
Place the female sounds in the sound/misc dir.
In your plugins.cfg replace stats.amxx with f_stats.amxx.
Replace the statsounds.amxx with the new one to precache sounds.
Credit 	sid luke- original stats plugin
	diamond optic- modified plugin
	bman 420	-ultimate stats female voices